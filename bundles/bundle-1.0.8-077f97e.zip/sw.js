// Pregnancy Companion — service worker
// Cache-first for built assets, network-first for navigations with cache fallback.
// Bumped automatically by the build via the embedded asset list (see install).

const CACHE_NAME = 'pregnancy-companion-v1';
const APP_SHELL = ['/', '/index.html', '/favicon.svg', '/manifest.webmanifest'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    Promise.all([
      caches
        .keys()
        .then((keys) =>
          Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))),
        ),
      self.clients.claim(),
    ]),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  // Skip cross-origin (Telegram, Firebase). Let them go to the network.
  if (url.origin !== self.location.origin) return;

  // SPA navigation: try the network, fall back to the cached index.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).catch(() =>
        caches.match('/index.html').then((cached) =>
          cached ?? new Response('Offline', { status: 503, statusText: 'Offline' }),
        ),
      ),
    );
    return;
  }

  // Static asset: cache-first, fall back to network and populate cache.
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((response) => {
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
          return response;
        })
        .catch(() => caches.match('/index.html') ?? new Response('', { status: 504 }));
    }),
  );
});
